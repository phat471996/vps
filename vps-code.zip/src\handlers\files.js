// File Manager Handler Module
// Handles all file management operations

module.exports = function (sshConn, execCommand) {

    function registerFileHandlers(socket) {

        // List Files
        socket.on('fm_list', (path) => {
            const isConnected = socket.handshake.isConnected;
            if (!isConnected) return;

            const cmd = `ls -lhp --group-directories-first "${path}" | awk 'NR>1 {print $1 "|" $3 "|" $4 "|" $5 "|" $9}'`;
            execCommand(cmd).then(out => {
                const items = out.split('\n').filter(Boolean).map(l => {
                    const p = l.split('|');
                    return p[4] ? {
                        name: p[4].replace('/', ''),
                        isDir: p[4].endsWith('/'),
                        size: p[3],
                        perms: p[0]
                    } : null;
                }).filter(Boolean);
                socket.emit('fm_list_result', { path, items });
            }).catch(e => socket.emit('cmd_log', `FM Error: ${e}`));
        });

        // Read File
        socket.on('fm_read', (p) => {
            execCommand(`cat "${p}"`).then(c => {
                socket.emit('fm_read_result', { path: p, content: c });
            }).catch(e => socket.emit('cmd_log', `FM Error: ${e}`));
        });

        // Save File
        socket.on('fm_save', ({ path, content }) => {
            sshConn.exec(`cat > "${path}"`, (err, s) => {
                if (!err) {
                    s.write(content);
                    s.end();
                }
            });
        });

        // File Actions (delete, mkdir, touch, rename, chmod)
        socket.on('fm_action', async ({ action, path: targetPath, newName }) => {
            const isConnected = socket.handshake.isConnected;
            if (!isConnected) return;

            let cmd = "";
            if (action === 'delete') cmd = `rm -rf "${targetPath}"`;
            if (action === 'mkdir') cmd = `mkdir -p "${targetPath}"`;
            if (action === 'touch') cmd = `touch "${targetPath}"`;
            if (action === 'rename') cmd = `mv "${targetPath}" "${newName}"`;
            if (action === 'chmod') cmd = `chmod -R 777 "${targetPath}"`;

            if (cmd) {
                try {
                    await execCommand(cmd);
                    socket.emit('fm_action_done');
                } catch (e) {
                    socket.emit('cmd_log', `FM Error: ${e}`);
                }
            }
        });

        // Backup Database
        socket.on('backup_db', async (dbName) => {
            const isConnected = socket.handshake.isConnected;
            if (!isConnected) return;

            const file = `/root/${dbName}_$(date +%F_%H-%M).sql`;
            socket.emit('cmd_log', `>>> Backup DB ${dbName}...\n`);
            try {
                await execCommand(`mysqldump ${dbName} > ${file}`);
                socket.emit('cmd_log', `>>> OK: ${file}\n`);
            } catch (e) {
                socket.emit('cmd_log', `Error: ${e}\n`);
            }
        });

        // Backup Website
        socket.on('backup_web', async (folderName) => {
            const isConnected = socket.handshake.isConnected;
            if (!isConnected) return;

            const target = `/var/www/html/${folderName}`;
            const file = `/root/${folderName}_backup_$(date +%F_%H-%M).zip`;
            socket.emit('cmd_log', `>>> Zipping ${target}...\n`);
            try {
                await execCommand(`zip -r ${file} ${target}`);
                socket.emit('cmd_log', `>>> OK: ${file}\n`);
            } catch (e) {
                socket.emit('cmd_log', `Error: ${e}\n`);
            }
        });
    }

    return { registerFileHandlers };
};
