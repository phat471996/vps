// Database Handler Module
// Handles all database-related socket events

module.exports = function (io, execCommand) {

    function registerDatabaseHandlers(socket) {

        // Create Super Admin Account for phpMyAdmin
        socket.on('db_create_super_admin', async ({ user, pass }) => {
            const isConnected = socket.handshake.isConnected;
            if (!isConnected) return;

            socket.emit('cmd_log', `>>> Đang tạo Admin '${user}'...\n`);

            try {
                // Helper function to run MySQL command using debian-sys-maint
                const runMysql = async (sql) => {
                    // Method 1: Try using debian-sys-maint credentials (Debian/Ubuntu default)
                    try {
                        const debianCmd = `mysql --defaults-extra-file=/etc/mysql/debian.cnf -e "${sql}"`;
                        return await execCommand(debianCmd);
                    } catch (e1) {
                        // Method 2: Try sudo mariadb
                        try {
                            return await execCommand(`sudo mariadb -e "${sql}"`);
                        } catch (e2) {
                            // Method 3: Try sudo mysql
                            try {
                                return await execCommand(`sudo mysql -e "${sql}"`);
                            } catch (e3) {
                                // Method 4: Try direct mariadb (no sudo)
                                try {
                                    return await execCommand(`mariadb -e "${sql}"`);
                                } catch (e4) {
                                    // Last resort: direct mysql
                                    return await execCommand(`mysql -e "${sql}"`);
                                }
                            }
                        }
                    }
                };

                // Bước 1: Xóa user nếu đã tồn tại (để tránh lỗi duplicate)
                socket.emit('cmd_log', `>>> Xóa user cũ (nếu có)...\n`);
                try {
                    await runMysql(`DROP USER IF EXISTS '${user}'@'localhost';`);
                    await runMysql(`DROP USER IF EXISTS '${user}'@'%';`);
                } catch (e) {
                    // Ignore errors if user doesn't exist
                }

                // Bước 2: Tạo user mới (MariaDB & MySQL compatible)
                socket.emit('cmd_log', `>>> Tạo user '${user}' cho localhost...\n`);
                await runMysql(`CREATE USER '${user}'@'localhost' IDENTIFIED BY '${pass}';`);

                socket.emit('cmd_log', `>>> Tạo user '${user}' cho remote...\n`);
                await runMysql(`CREATE USER '${user}'@'%' IDENTIFIED BY '${pass}';`);

                // Bước 3: Cấp quyền admin đầy đủ
                socket.emit('cmd_log', `>>> Cấp quyền admin...\n`);
                await runMysql(`GRANT ALL PRIVILEGES ON *.* TO '${user}'@'localhost' WITH GRANT OPTION;`);
                await runMysql(`GRANT ALL PRIVILEGES ON *.* TO '${user}'@'%' WITH GRANT OPTION;`);
                await runMysql(`FLUSH PRIVILEGES;`);

                socket.emit('cmd_log', `\n✅ THÀNH CÔNG! Đăng nhập phpMyAdmin:\n   👤 Username: ${user}\n   🔑 Password: ${pass}\n\n`);
                io.emit('db_action_success');
            } catch (e) {
                socket.emit('cmd_log', `\n❌ LỖI: ${e}\n\nGợi ý: Kiểm tra quyền truy cập MySQL hoặc thử 'Fix Web Default' ở tab 'Kho & Fix'.\n`);
            }
        });

        // List Databases
        socket.on('db_list_pro', async () => {
            const isConnected = socket.handshake.isConnected;
            if (!isConnected) return;
            try {
                const raw = await execCommand(`sudo mysql -N -B -e "SELECT table_schema, ROUND(SUM(data_length + index_length)/1024/1024, 1) FROM information_schema.TABLES GROUP BY table_schema;"`);
                const dbs = raw.split('\n').filter(Boolean).map(l => {
                    const [name, size] = l.split('\t');
                    return { name, size: size || "0" };
                }).filter(d => !['information_schema', 'mysql', 'performance_schema', 'sys'].includes(d.name));
                socket.emit('db_list_result', dbs);
            } catch (e) {
                socket.emit('db_list_result', []);
            }
        });

        // List Database Users
        socket.on('db_user_list', async () => {
            const isConnected = socket.handshake.isConnected;
            if (!isConnected) return;
            try {
                const r = await execCommand(`sudo mysql -N -B -e "SELECT User,Host FROM mysql.user"`);
                socket.emit('db_user_list_result', r.split('\n').filter(Boolean).map(l => {
                    const [u, h] = l.split('\t');
                    return { user: u, host: h };
                }).filter(u => !['root', 'mysql.session', 'mysql.sys'].includes(u.user)));
            } catch (e) {
                socket.emit('db_user_list_result', []);
            }
        });

        // Create Full Database with User
        socket.on('db_create_full', async ({ name, user, pass }) => {
            const isConnected = socket.handshake.isConnected;
            if (!isConnected) return;
            const sql = `CREATE DATABASE IF NOT EXISTS ${name};CREATE USER IF NOT EXISTS '${user}'@'localhost' IDENTIFIED BY '${pass}';GRANT ALL PRIVILEGES ON ${name}.* TO '${user}'@'localhost';FLUSH PRIVILEGES;`;
            try {
                await execCommand(`sudo mysql -e "${sql}"`);
                io.emit('db_action_success');
            } catch (e) {
                socket.emit('cmd_log', e);
            }
        });

        // Delete Database
        socket.on('db_delete', async (n) => {
            const isConnected = socket.handshake.isConnected;
            if (!isConnected) return;
            try {
                await execCommand(`sudo mysql -e "DROP DATABASE ${n}"`);
                io.emit('db_action_success');
            } catch (e) {
                socket.emit('cmd_log', `Error: ${e}`);
            }
        });

        // Delete User
        socket.on('db_user_delete', async ({ user, host }) => {
            const isConnected = socket.handshake.isConnected;
            if (!isConnected) return;
            try {
                await execCommand(`sudo mysql -e "DROP USER '${user}'@'${host}'"`);
                io.emit('db_action_success');
            } catch (e) {
                socket.emit('cmd_log', `Error: ${e}`);
            }
        });

        // --- INACTIVE ACCOUNTS MANAGEMENT ---

        // Create Inactive Account
        socket.on('db_create_inactive', async ({ user, pass }) => {
            const isConnected = socket.handshake.isConnected;
            if (!isConnected) return;
            socket.emit('cmd_log', `>>> Tạo tài khoản chưa kích hoạt '${user}'...\n`);
            try {
                const sqlLocal = `CREATE USER IF NOT EXISTS '${user}'@'localhost' IDENTIFIED BY '${pass}';`;
                const sqlRemote = `CREATE USER IF NOT EXISTS '${user}'@'%' IDENTIFIED BY '${pass}';`;
                const sqlFlush = `FLUSH PRIVILEGES;`;
                await execCommand(`sudo mysql -e "${sqlLocal}"`);
                await execCommand(`sudo mysql -e "${sqlRemote}"`);
                await execCommand(`sudo mysql -e "${sqlFlush}"`);
                socket.emit('cmd_log', `>>> Tạo thành công! Tài khoản '${user}' chưa có quyền truy cập.\n`);
                io.emit('db_action_success');
            } catch (e) {
                socket.emit('cmd_log', `>>> LỖI: ${e}\n`);
            }
        });

        // List Inactive Accounts
        socket.on('db_list_inactive', async () => {
            const isConnected = socket.handshake.isConnected;
            if (!isConnected) return;
            try {
                // Get all users first
                const allUsers = await execCommand(`sudo mysql -N -B -e "SELECT User,Host FROM mysql.user WHERE User NOT IN ('root','mysql.session','mysql.sys','mysql.infoschema','debian-sys-maint')"`);
                const users = allUsers.split('\n').filter(Boolean).map(l => {
                    const [u, h] = l.split('\t');
                    return { user: u, host: h };
                });

                // Check which users have no privileges (inactive)
                const inactive = [];
                for (const u of users) {
                    try {
                        const grants = await execCommand(`sudo mysql -N -B -e "SHOW GRANTS FOR '${u.user}'@'${u.host}'"`);
                        // If user only has USAGE privilege (no real privileges), they're inactive
                        if (grants.includes('GRANT USAGE ON') && !grants.includes('GRANT ALL') && !grants.includes('GRANT SELECT')) {
                            inactive.push(u);
                        }
                    } catch (e) {
                        // If we can't get grants, assume inactive
                        inactive.push(u);
                    }
                }
                socket.emit('db_inactive_list_result', inactive);
            } catch (e) {
                socket.emit('db_inactive_list_result', []);
            }
        });

        // Activate User
        socket.on('db_activate_user', async ({ user, host }) => {
            const isConnected = socket.handshake.isConnected;
            if (!isConnected) return;
            socket.emit('cmd_log', `>>> Kích hoạt tài khoản '${user}'@'${host}'...\n`);
            try {
                const sql = `GRANT ALL PRIVILEGES ON *.* TO '${user}'@'${host}' WITH GRANT OPTION; FLUSH PRIVILEGES;`;
                await execCommand(`sudo mysql -e "${sql}"`);
                socket.emit('cmd_log', `>>> Kích hoạt thành công! Tài khoản '${user}' đã có quyền đầy đủ.\n`);
                io.emit('db_action_success');
            } catch (e) {
                socket.emit('cmd_log', `>>> LỖI: ${e}\n`);
            }
        });
    }

    return { registerDatabaseHandlers };
};
