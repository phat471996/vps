// System Stats & Monitoring Handler Module
// Handles system statistics, process listing, and service checking

module.exports = function (io, execCommand, safeExec) {

    async function fetchStats() {
        const os = await safeExec("cat /etc/os-release | grep PRETTY_NAME | cut -d= -f2 | tr -d '\\\"'", "Linux");
        const memInfo = await safeExec("cat /proc/meminfo", "");

        let ramFmt = "0|0|0";
        if (memInfo) {
            try {
                const total = (memInfo.match(/MemTotal:\s+(\d+)/) || [0, 0])[1];
                const avail = (memInfo.match(/MemAvailable:\s+(\d+)/) || [0, 0])[1];
                const used = parseInt(total) - parseInt(avail);
                ramFmt = `${Math.round(used / 1024)}|${Math.round(total / 1024)}|0`;
            } catch (e) { }
        }

        const disk = await safeExec("df -h / | awk 'NR==2{print $3 \"/\" $2 \" (\" $5 \")\"}'", "N/A");
        const load = await safeExec("cat /proc/loadavg | awk '{print $1}'", "0.0");
        const cpuModel = await safeExec("grep -m1 'model name' /proc/cpuinfo | cut -d: -f2", "Virtual CPU");
        const cpuCores = await safeExec("nproc", "1");
        const uptimeRaw = await safeExec("cat /proc/uptime", "0");
        const upSec = parseFloat(uptimeRaw.split(' ')[0]);
        const uptime = `${Math.floor(upSec / 3600)}h ${Math.floor((upSec % 3600) / 60)}m`;

        io.emit('stats_update', {
            os,
            ram: ramFmt,
            disk,
            load,
            uptime,
            cpuModel: cpuModel.trim(),
            cpuCores: cpuCores.trim()
        });
    }

    async function checkInstalledServices() {
        try {
            const cmd = `
                which nginx > /dev/null 2>&1 && echo "nginx:1" || echo "nginx:0"
                which docker > /dev/null 2>&1 && echo "docker:1" || echo "docker:0"
                which node > /dev/null 2>&1 && echo "node:1" || echo "node:0"
                which php > /dev/null 2>&1 && echo "php:1" || echo "php:0"
                which mysql > /dev/null 2>&1 && echo "mysql:1" || echo "mysql:0"
                which pm2 > /dev/null 2>&1 && echo "pm2:1" || echo "pm2:0"
                which git > /dev/null 2>&1 && echo "git:1" || echo "git:0"
                which python3 > /dev/null 2>&1 && echo "python3:1" || echo "python3:0"
                which zip > /dev/null 2>&1 && echo "zip:1" || echo "zip:0"
                if [ -d "/usr/share/phpmyadmin" ]; then echo "phpmyadmin:1"; else echo "phpmyadmin:0"; fi
            `;
            const result = await execCommand(cmd);
            const services = {};
            result.split('\n').forEach(line => {
                const [name, status] = line.split(':');
                if (name) services[name] = status === '1';
            });
            io.emit('services_status', services);
        } catch (e) { }
    }

    async function fetchProcesses() {
        try {
            let cmd = `ps -Ao pid,user,pmem,pcpu,comm --sort=-pmem | head -n 16`;
            let res = "";
            try {
                res = await execCommand(cmd);
            } catch {
                res = await execCommand(`ps aux | head -n 16`);
            }
            io.emit('process_list', res);
        } catch (e) {
            io.emit('process_list', "Error fetching processes");
        }
    }

    function registerSystemHandlers(socket) {
        socket.on('refresh_all', () => {
            fetchStats();
            checkInstalledServices();
        });

        socket.on('get_processes', () => fetchProcesses());

        socket.on('get_log', async (t) => {
            const isConnected = socket.handshake.isConnected;
            if (!isConnected) return;

            let p = "/var/log/syslog";
            if (t === 'auth') p = '/var/log/auth.log';
            if (t === 'nginx_error') p = '/var/log/nginx/error.log';
            if (t === 'mysql_error') p = '/var/log/mysql/error.log';

            try {
                const c = await execCommand(`tail -n 50 ${p}`);
                socket.emit('log_content', c);
            } catch (e) {
                socket.emit('log_content', `Err: ${e}`);
            }
        });
    }

    return {
        fetchStats,
        checkInstalledServices,
        fetchProcesses,
        registerSystemHandlers
    };
};
