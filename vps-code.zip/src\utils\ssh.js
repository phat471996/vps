// SSH Connection Utility Module
// Manages SSH connections and command execution

const { Client } = require('ssh2');
const fs = require('fs');
const path = require('path');

const CONFIG_FILE = path.join(__dirname, '../../vps-config.json');

let sshConn = null;
let isConnected = false;

function saveConfig(config) {
    try {
        fs.writeFileSync(CONFIG_FILE, JSON.stringify(config, null, 2));
    } catch (e) { }
}

function loadConfig() {
    try {
        return JSON.parse(fs.readFileSync(CONFIG_FILE));
    } catch (e) {
        return null;
    }
}

function execCommand(command) {
    return new Promise((resolve, reject) => {
        if (!sshConn || !isConnected) return reject("Mất kết nối VPS!");
        sshConn.exec(command, (err, stream) => {
            if (err) return reject(err);
            let stdout = '';
            let stderr = '';
            stream.on('data', (chunk) => { stdout += chunk; })
                .stderr.on('data', (chunk) => { stderr += chunk; })
                .on('close', (code) => {
                    if (stdout.trim().length > 0) resolve(stdout.trim());
                    else if (code !== 0 && stderr.trim().length > 0) reject(stderr);
                    else resolve("");
                });
        });
    });
}

async function safeExec(cmd, fallback = "N/A") {
    try {
        return await execCommand(cmd);
    } catch (e) {
        console.warn(`[CMD WARN] "${cmd}" failed: ${e}`);
        return fallback;
    }
}

function connectToVPS(config, socket, io, onConnected) {
    if (sshConn) sshConn.end();

    sshConn = new Client();

    sshConn.on('ready', () => {
        console.log(`Connected: ${config.host}`);
        isConnected = true;
        if (socket) socket.emit('login_success', { host: config.host });
        io.emit('login_success', { host: config.host });

        // Callback for additional setup (check services, start monitoring, etc.)
        if (onConnected) onConnected();
    }).on('error', (err) => {
        isConnected = false;
        if (socket) socket.emit('login_error', err.message);
    });

    try {
        sshConn.connect({
            host: config.host,
            port: parseInt(config.port) || 22,
            username: config.username,
            password: config.password,
            readyTimeout: 10000
        });
    } catch (e) {
        if (socket) socket.emit('login_error', e.message);
    }
}

function getConnection() {
    return { sshConn, isConnected };
}

function setConnectionStatus(status) {
    isConnected = status;
}

module.exports = {
    connectToVPS,
    execCommand,
    safeExec,
    saveConfig,
    loadConfig,
    getConnection,
    setConnectionStatus
};
