const express = require('express');
const http = require('http');
const socketIo = require('socket.io');
const path = require('path');

// Import utilities and handlers
const sshUtils = require('./src/utils/ssh');
const databaseModule = require('./src/handlers/database');
const filesModule = require('./src/handlers/files');
const systemModule = require('./src/handlers/system');
const servicesModule = require('./src/handlers/services');

const app = express();
const server = http.createServer(app);
const io = socketIo(server);

const PORT = 3000;

let statsInterval = null;
let activeClients = 0;

app.use(express.static(path.join(__dirname, 'public')));

// Start monitoring stats
function startMonitoring() {
    if (statsInterval) clearInterval(statsInterval);
    const { fetchStats } = systemModule(io, sshUtils.execCommand, sshUtils.safeExec);
    statsInterval = setInterval(() => {
        if (activeClients > 0) fetchStats();
    }, 4000);
}

// Socket.IO connection handler
io.on('connection', (socket) => {
    activeClients++;

    // Store connection status on socket handshake for easy access
    const { isConnected } = sshUtils.getConnection();
    socket.handshake.isConnected = isConnected;

    const conf = sshUtils.loadConfig();
    if (conf) {
        socket.emit('auth_status', { hasConfig: true, host: conf.host });
        if (!isConnected) {
            sshUtils.connectToVPS(conf, socket, io, () => {
                const { checkInstalledServices } = systemModule(io, sshUtils.execCommand, sshUtils.safeExec);
                checkInstalledServices();
                startMonitoring();
                socket.handshake.isConnected = true;
            });
        } else {
            const { checkInstalledServices } = systemModule(io, sshUtils.execCommand, sshUtils.safeExec);
            checkInstalledServices();
        }
    } else {
        socket.emit('auth_status', { hasConfig: false });
    }

    // Update connection status on socket
    socket.use((packet, next) => {
        const { isConnected } = sshUtils.getConnection();
        socket.handshake.isConnected = isConnected;
        next();
    });

    // Register all handlers
    const { sshConn } = sshUtils.getConnection();

    const { registerDatabaseHandlers } = databaseModule(io, sshUtils.execCommand);
    registerDatabaseHandlers(socket);

    const { registerFileHandlers } = filesModule(sshConn, sshUtils.execCommand);
    registerFileHandlers(socket);

    const { registerSystemHandlers } = systemModule(io, sshUtils.execCommand, sshUtils.safeExec);
    registerSystemHandlers(socket);

    const { registerServiceHandlers } = servicesModule(sshConn, sshUtils.execCommand);
    registerServiceHandlers(socket);

    // Login/Logout handlers
    socket.on('login', (data) => {
        sshUtils.saveConfig(data);
        sshUtils.connectToVPS(data, socket, io, () => {
            const { checkInstalledServices } = systemModule(io, sshUtils.execCommand, sshUtils.safeExec);
            checkInstalledServices();
            startMonitoring();
            socket.handshake.isConnected = true;
        });
    });

    socket.on('logout', () => {
        const fs = require('fs');
        const CONFIG_FILE = path.join(__dirname, 'vps-config.json');
        if (fs.existsSync(CONFIG_FILE)) fs.unlinkSync(CONFIG_FILE);

        const { sshConn } = sshUtils.getConnection();
        if (sshConn) sshConn.end();
        sshUtils.setConnectionStatus(false);
        socket.emit('auth_status', { hasConfig: false });
    });

    socket.on('disconnect', () => {
        activeClients--;
    });
});

server.listen(PORT, () => console.log(`http://localhost:${PORT}`));