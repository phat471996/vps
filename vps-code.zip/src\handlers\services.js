// Service Installation & Configuration Handler Module
// Handles software installation and web server configuration

module.exports = function (sshConn, execCommand) {

    function registerServiceHandlers(socket) {

        // Fix Default Web Configuration (Nginx + phpMyAdmin)
        socket.on('fix_default_web', async () => {
            const isConnected = socket.handshake.isConnected;
            if (!isConnected) return;

            socket.emit('cmd_log', `>>> Bắt đầu Fix Nginx & phpMyAdmin...\n`);
            await execCommand('apt-get update -y && DEBIAN_FRONTEND=noninteractive apt-get install -y nginx mariadb-server php-fpm php-mysql php-mbstring php-zip php-gd phpmyadmin zip unzip');

            let phpSocket = "";
            try {
                const f = await execCommand("ls /run/php/php*-fpm.sock 2>/dev/null | sort -V | tail -n 1");
                if (f && f.trim()) phpSocket = f.trim();
            } catch (e) { }
            if (!phpSocket) phpSocket = "/run/php/php8.1-fpm.sock";

            const passPath = `unix:${phpSocket}`;
            const nginxConfig = `
server {
    listen 80 default_server;
    listen [::]:80 default_server;
    root /var/www/html;
    index index.php index.html index.htm;
    server_name _;
    location / { try_files \\$uri \\$uri/ =404; }
    location /phpmyadmin {
        root /usr/share/;
        index index.php index.html;
        location ~ ^/phpmyadmin/(.+\\.php)$ {
            try_files \\$uri =404;
            root /usr/share/;
            fastcgi_pass ${passPath};
            fastcgi_index index.php;
            fastcgi_param SCRIPT_FILENAME \\$document_root\\$fastcgi_script_name;
            include fastcgi_params;
        }
        location ~* ^/phpmyadmin/(.+\\.(jpg|jpeg|gif|css|png|js|ico|html|xml|txt))$ { root /usr/share/; }
    }
    location ~ \\.php$ { include snippets/fastcgi-php.conf; fastcgi_pass ${passPath}; }
}
`;
            const script = `
[ -f /etc/nginx/sites-available/default ] && mv /etc/nginx/sites-available/default /etc/nginx/sites-available/default.bak_$(date +%s)
cat > /etc/nginx/sites-available/default <<EOF
${nginxConfig}
EOF
ln -sf /etc/nginx/sites-available/default /etc/nginx/sites-enabled/
chown -R www-data:www-data /var/www/html
chmod -R 755 /var/www/html
systemctl restart php*-fpm
nginx -t && systemctl restart nginx
echo "<?php phpinfo(); ?>" > /var/www/html/info.php
            `;

            sshConn.exec(script, (err, stream) => {
                stream.on('data', d => socket.emit('cmd_log', d.toString()))
                    .on('close', () => socket.emit('cmd_log', `\n>>> XONG! Hãy thử truy cập lại phpMyAdmin.\n`));
            });
        });

        // Generic Command Installation
        socket.on('install_cmd', (cmd) => {
            const isConnected = socket.handshake.isConnected;
            if (!isConnected) return;

            socket.emit('cmd_log', `\n> ${cmd}\n`);
            sshConn.exec(cmd, (err, stream) => {
                if (!err) {
                    stream.on('data', d => socket.emit('cmd_log', d.toString()))
                        .on('close', () => {
                            // Re-check services after installation
                            const systemModule = require('./system');
                            const { checkInstalledServices } = systemModule(require('socket.io')(), execCommand, () => { });
                            checkInstalledServices();
                        });
                }
            });
        });
    }

    return { registerServiceHandlers };
};
